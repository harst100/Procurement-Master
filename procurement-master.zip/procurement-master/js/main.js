//Global variables
var result = '';
const contract = require('./blockchain');
const logger = require('./logger')

var transferred_args = process.argv.slice(2);

const transferred_args_json = JSON.parse(transferred_args[0]);

//Switch cases for calling different functions
(async () => {
    switch (transferred_args_json.command){
        case 'add_request':
            //console.error('case add_request');
            result = await contract.addRequest(transferred_args_json.request_id,
                transferred_args_json.title, transferred_args_json.amount, transferred_args_json.max_costs, 
                transferred_args_json.procurement_hash);
            console.error('result after BC: ', result);
            break;

        case "get_request":
             //console.error("get_request.");
            result = await contract.getRequest(transferred_args_json.request_id);
            console.error("Successfully Injected  --> ");
            console.error(result);
            break;

        case "place_bid":
            //console.error("place_bid.");
            result = await contract.placeBid(transferred_args_json.request_id, transferred_args_json.sender_address, transferred_args_json.bidding_hash, transferred_args_json.offer_hash);
            console.error(result)
            break;
        
        case "reveal_bid":
            console.error("reveal_bid.");
            result = await contract.revealBid(transferred_args_json.request_id, transferred_args_json.sender_address, transferred_args_json.price, transferred_args_json.nonce);
            console.error(result)
            break;

        case "get_lowest_bid":
            //console.error("get_lowest_bid.");
            result = await contract.getLowestBid(transferred_args_json.request_id);
            result = JSON.stringify(result);
            console.error(result)
            break;

        case "set_state":
            //console.error("set_state.");
            result = await contract.setState(transferred_args_json.request_id, transferred_args_json.state);
            console.error(result)
            break;

        case "get_state":
            //console.error("get_state.");
            result = await contract.getState(transferred_args_json.request_id);
            //result = JSON.stringify(result);
            console.error(result)
            break;
        
        case "get_proposals":
            //console.error("get_proposals.");
            result = await contract.getProposals(transferred_args_json.request_id);
            result = JSON.stringify(result);
            console.error(result);
            break;
        
        case "withdraw":
            //console.error("withdraw.");
            result = await contract.withdraw(transferred_args_json.request_id, transferred_args_json.sender_address);
            result = JSON.stringify(result);
            console.error(result);
            break;

        case "create_identity":
            //console.error("create_identity.");
            result = await contract.createIdentity(transferred_args_json.sender_address);
            console.error(result);
            break;

        case "set_sign_proof":
            //console.error("set_sign_proof.");
            result = await contract.setSignProof(transferred_args_json.authority, transferred_args_json.business_address);
            console.error(result);
            break;

        case "get_sign_proof":
            //console.error("get_sign_proof.");
            result = await contract.getSignProof();
            result = JSON.stringify(result);
            console.error(result);
            break;

        case "reveal_proof":
            //console.error("reveal_proof.");
            result = await contract.revealProof(transferred_args_json.request_id);
            console.error(result);
            break;

        case "get_proposal_state":
            //console.error("get_proposal_state.");
            result = await contract.getProposalState(transferred_args_json.request_id, transferred_args_json.sender_address);
            console.error(result);
            break;

        case "get_reveal_proof":
            //console.error("get_reveal_proof.");
            result = await contract.getRevealProof();
            console.error(result);
            break;

        case "set_order":
            //console.error("set_order.");
            result = await contract.setOrder(transferred_args_json.request_id);
            console.error(result);
            break;
        
        case "set_order_depot":
            //console.error("set_order_depot.");
            result = await contract.setOrderDepot(transferred_args_json.request_id, transferred_args_json.sender_name);
            console.error(result);
            break;

        case "order_received":
            //console.error("order_received.");
            result = await contract.orderReceived(transferred_args_json.request_id,transferred_args_json.sender_address);
            console.error(result);
            break;

        case "sign_order":
            //console.error("sign_order.");
            result = await contract.signOrder(transferred_args_json.request_id,transferred_args_json.sender_address, transferred_args_json.quality, transferred_args_json.delivered_amount);
            console.error(result);
            break;
    
        case "get_delivery":
            //console.error("get_delivery.");
            result = await contract.getDelivery(transferred_args_json.request_id);
            result = JSON.stringify(result);
            console.error(result);
            break;

        case "init_modifier":
            //console.error("init_modifier.");
            console.error("init_modifier" + transferred_args_json.init_authorities);
            result = await contract.initModifier(transferred_args_json.init_authorities,transferred_args_json.init_gov_employee);
            console.error(result);
            break;
    }            
    console.log(result)
})();

