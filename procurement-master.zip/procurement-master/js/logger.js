const { createLogger, format, transports } = require('winston')
const { combine, timestamp, printf } = format

const myFormat = printf(info => {
  return `${info.timestamp} | ${info.level} : ${info.message}`
})

const logger = createLogger({
  transports: [
    new transports.File({
      filename: 'procurement/log/application.log',
      level: 'silly',
      format: combine(timestamp(), myFormat),
    }),
    new transports.File({
      filename: 'procurement/log/error.log',
      level: 'error',
      format: combine(timestamp(), myFormat),
    }),
    /*new transports.Console({
      level: 'debug',
      format: combine(format.colorize(), timestamp(), myFormat),
    }),*/
  ],
})

module.exports = logger
