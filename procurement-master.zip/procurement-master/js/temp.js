var result = JSON.parse(msg.payload)
var table_view = [] ;
for (i=0; i<10; i++) {
    if(msg.payload[0][i] != "0x0000000000000000000000000000000000000000000000000000000000000000") {

        table_view.push({"business_address" : msg.payload[0][i], "proposal_bid_hash" : msg.payload[1][i]});
              
    }
    
}
msg.payload = result;

return msg;



