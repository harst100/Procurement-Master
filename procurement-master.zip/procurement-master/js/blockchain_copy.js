const Web3 = require('web3');
const logger = require('./logger')
const ContractConfig = require('../solidity/build/contracts/procurement_contract.json');
const { isTopic } = require('web3-utils');

const SETTINGS = {
    PROVIDER: 'http://127.0.0.1:7545',
    PRIVATE_KEY: '4066dd3f54a87e906769317a4a767d133f34b01414349fcae4dd9f5f97f0a00f',
    SENDER: '0xCc30fD1B1Df91BD83AE80C9Afa256B793ac825d6'
}

class Blockchain{

    //constructor
    constructor() {
        try {
          logger.debug('start construtor')
          this.settings = SETTINGS
    
          this.events = {
            CONFIRM_FINALDISPOSITION: 'recordToConfirmFinaldisposition',
            READY_FINALDISPOSITION: 'recordReadyFinaldisposition',
            RETENTION_DONE: 'recordRetentionDone',
            RECORD_ADDED: 'newRecordAdded',
          }
    
          this.settings.CONTRACT_ADDRESS = ContractConfig.networks['5777'].address
          logger.debug('privateKey ' + this.settings.PRIVATE_KEY)
          this.web3 = new Web3(this.settings.PROVIDER)
          //this.web3.eth.accounts.wallet.add(this.sanitize(this.settings.PRIVATE_KEY))
          if (!this.web3.utils.isAddress(this.settings.CONTRACT_ADDRESS)) throw new Error("Invalid Contract Address")
          this.contract = new this.web3.eth.Contract(ContractConfig.abi, ContractConfig.networks[5777].address)
          // this.settings.CONTRACT_ADDRESS)
          logger.debug('end construtor')
        } catch (e) {
          if (e.message) {
            return Promise.reject(new Error(e.message))
          }
        }
      }

      /*
    __parseReceipt(receipt) {
        return { txId: receipt.transactionHash, block: receipt.blockNumber }
      }
      */
     /*
     async estimateGas(contractCall, sender) {
        try {
          let gasAmount = await contractCall.estimateGas({ gas: GAS_FALLBACK_AMOUNT, from: sender })
          if (!gasAmount) gasAmount = GAS_FALLBACK_AMOUNT
          logger.silly(`Gas estimate is ${gasAmount}`)
          return gasAmount
        } catch (e) {
          logger.error('estimateGasCatch', e)
          return GAS_FALLBACK_AMOUNT
        }
      }
     */
     
      async executeSend(contractCall, sender, msg_value, switch_case) {
        //const gasAmount = await this.estimateGas(contractCall, sender)
        logger.debug(`executeSend started`)
        if(switch_case == 'default'){ 
        logger.debug(`executeSend started with msg.value 0`)
        const gasAmount = 500000
        return await contractCall.send({ from: sender, gas: gasAmount })
          .on('transactionHash', function (hash) {
            logger.silly(`transactionHash for addRequest is ${hash}. Waiting for Block Inclusion...`)
          })
        }
              
        else if(switch_case == 'proposal_depot'){
          logger.debug(`executeSend started with msg.value 1 ETH`)
          const gasAmount = 500000
          return await contractCall.send({ from: sender, gas: gasAmount, value: msg_value })
            .on('transactionHash', function (hash) {
              logger.silly(`transactionHash for placeBid is ${hash}. Waiting for Block Inclusion...`)
            })

        }


        else if(switch_case == 'bus_order_depot') {   //sehr unsauber gelöst, wenn msg_value =1, wird der msg_value vom lowest bidder ausgewählt
          

        } 

        
        
        
        
        else{
          logger.debug(`executeSend: Failed, msg_value does not match condition `)
        }    

      }

    async addRequest(request_id, proposer, category, title, description, amount, max_costs, delivery_date, bidding_depot, 
      filtration_percentage, leak_rate, color){
      
        //const sender = this.addKeyToWallet('0xCc30fD1B1Df91BD83AE80C9Afa256B793ac825d6')
      logger.debug(`Add Request ${request_id} ${title} `)
      const contractCall = this.contract.methods['add_request'](request_id, proposer, category, title, description, amount, max_costs, 
      delivery_date, bidding_depot, filtration_percentage, leak_rate, color)
      const receipt = await this.executeSend(contractCall, '0xCc30fD1B1Df91BD83AE80C9Afa256B793ac825d6', 0, 'default') //zero = msg.value used for placeBid and revealBid
      return receipt
    }

    async getRequest(request_id) {
      return await this.contract.methods['get_request'](request_id).call()

    }

    async placeBid(request_id, sender_address, bidding_hash, offer_hash){
      logger.debug(`place Bid ${request_id} ${bidding_hash} ${offer_hash}`)
      const contractCall = this.contract.methods['place_bid'](request_id, bidding_hash, offer_hash)
      const receipt = await this.executeSend(contractCall, sender_address, 1000000000000000000,'proposal_depot') //1 ETH = depot for bidding in msg.value payload
      return receipt
    } 

    async revealBid(request_id, sender_address, price, nonce){
      logger.debug(`reveal Bid ${request_id} ${price} ${nonce}`)
      const contractCall = this.contract.methods['reveal_bid'](request_id, price, nonce)
      const receipt = await this.executeSend(contractCall, sender_address, 0,'default') //zero = msg.value used for placeBid and revealBid
      
      return receipt
    } 

    async getLowestBid(request_id){
      logger.debug(`getLowestBid`)
      return await this.contract.methods['get_lowest_bid'](request_id).call()
    } 

    async setState(request_id, state){
      logger.debug(`set State ${request_id} ${state}`)
      const contractCall = this.contract.methods['set_state'](request_id, state)
      const receipt = await this.executeSend(contractCall, '0xCc30fD1B1Df91BD83AE80C9Afa256B793ac825d6', 0, 'default') //zero = msg.value used for placeBid and revealBid
      return receipt
    } 

    async getState(request_id) {
      return await this.contract.methods['get_state'](request_id).call()
    }

    async getProposals(request_id) {
      return await this.contract.methods['get_proposals'](request_id).call()
    }

    async withdraw(request_id, sender_address){
      logger.debug(`withdraw ${request_id} ${sender_address}`)
      const contractCall = this.contract.methods['withdraw'](request_id)
      const receipt = await this.executeSend(contractCall, sender_address, 0, 'default') //zero = msg.value used for withdraw
      return receipt
    } 

    async createIdentity(sender_address){
      logger.debug(`create Identity ${sender_address}`)
      const contractCall = this.contract.methods['create_identity'](sender_address)
      const receipt = await this.executeSend(contractCall, sender_address, 0, 'default') //zero = msg.value used for create identity
      return receipt
    }

    async setSignProof(authority, business_address){
      logger.debug(`set sign proof ${authority} ${business_address}`)
      const contractCall = this.contract.methods['set_sign_proof'](authority, business_address)
      if(authority == 'finance'){ 
       logger.debug(`set sign proof: authority finance will sign`)
       const receipt = await this.executeSend(contractCall, '0x695F46117a73B519921BC4475bF265eE747094E5', 0, 'default') //zero = msg.value used for create identity
       return receipt
      }
      if(authority == 'employee'){
        logger.debug(`set sign proof: authority employee will sign`)
        const receipt = await this.executeSend(contractCall, '0x52989aDfAfCE20f440E8e9247267F12CC23D37aA', 0, 'default') //zero = msg.value used for create identity
        return receipt
      }  
    }
    
    async getSignProof() {
      return await this.contract.methods['get_sign_proof']().call()
    }

    async revealProof(request_id){
      logger.debug(`revealProof ${request_id}`)
      const contractCall = this.contract.methods['reveal_proof'](request_id)
      const receipt = await this.executeSend(contractCall, '0xCc30fD1B1Df91BD83AE80C9Afa256B793ac825d6', 0, 'default') //zero = msg.value used for create identity
      
      return receipt
    }

    async getProposalState(request_id, sender_address){
      logger.debug(`getProposalState ${request_id} ${sender_address} `)
      return await this.contract.methods['get_proposal_state'](request_id,sender_address).call()
    }

    async getRevealProof(){
      logger.debug(`getRevealProof`)
      return await this.contract.methods['get_reveal_proof']().call()
    }

    async setOrder(request_id){ //kann nur vom Staat ausgeführt werden 
      logger.debug(`setOrder ${request_id}`)
      const contractCall = this.contract.methods['set_order'](request_id)
      const receipt = await this.executeSend(contractCall, '0xCc30fD1B1Df91BD83AE80C9Afa256B793ac825d6', 0, 'default')
      return receipt
    } 

    async setOrderDepot(request_id, sender_address){ //kann nur vom Staat ausgeführt werden 
      
      winner_costs = await this.contract.methods['get_lowest_bid'](request_id).call()
      winner_costs = winner_costs[_lowest_bid] 
      winner_costs = winner_costs * 1000000000000000000 //Wei
      if("0xCc30fD1B1Df91BD83AE80C9Afa256B793ac825d6" == sender_address){
      logger.debug(`setOrderDepot Gov ${request_id}`)
      const contractCall = this.contract.methods['set_order_depot'](request_id)
      const receipt = await this.executeSend(contractCall,sender_address,winner_costs,'gov_order_depot' )
      return receipt
     } 

     else{
      winner_costs = winner_costs * 0.05 * 1000000000000000000 //wei
      logger.debug(`setOrderDepot Bus. ${request_id}`)
      const contractCall = this.contract.methods['set_order_depot'](request_id)
      const receipt = await this.executeSend(contractCall, sender_address, winner_costs, 'bus_order_depot')
      return receipt
     } 
    
    } 





} 

module.exports = new Blockchain()