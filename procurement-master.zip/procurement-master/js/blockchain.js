//Global variables
const Web3 = require('web3');
const logger = require('./logger')
const ContractConfig = require('../solidity/build/contracts/procurement_contract.json');
const { isTopic } = require('web3-utils');

const SETTINGS = {
    PROVIDER: 'http://127.0.0.1:7545',
    PRIVATE_KEY: '4066dd3f54a87e906769317a4a767d133f34b01414349fcae4dd9f5f97f0a00f',
    SENDER: '0xCc30fD1B1Df91BD83AE80C9Afa256B793ac825d6'
}

class Blockchain{
    //constructor
  constructor() {
      try {
        logger.debug('start construtor')
        this.settings = SETTINGS
  
        this.events = {
          CONFIRM_FINALDISPOSITION: 'recordToConfirmFinaldisposition',
          READY_FINALDISPOSITION: 'recordReadyFinaldisposition',
          RETENTION_DONE: 'recordRetentionDone',
          RECORD_ADDED: 'newRecordAdded',
        }
  
        this.settings.CONTRACT_ADDRESS = ContractConfig.networks['5777'].address
        logger.debug('privateKey ' + this.settings.PRIVATE_KEY)
        this.web3 = new Web3(this.settings.PROVIDER)
        if (!this.web3.utils.isAddress(this.settings.CONTRACT_ADDRESS)) throw new Error("Invalid Contract Address")
        this.contract = new this.web3.eth.Contract(ContractConfig.abi, ContractConfig.networks[5777].address)
        logger.debug('end construtor')
      } catch (e) {
        if (e.message) {
          return Promise.reject(new Error(e.message))
        }
      }
  }
    
  //Do contract call
  async executeSend(contractCall, sender, msg_value) {
    logger.debug(`executeSend started`)
    logger.debug(`executeSend started with msg.value 0`)
    const gasAmount = 500000
    return await contractCall.send({ from: sender, gas: gasAmount, value: msg_value })
      .on('transactionHash', function (hash) {
        logger.silly(`transactionHash for addRequest is ${hash}. Waiting for Block Inclusion...`)
      })
  }

  //adding a request
  async addRequest(request_id, title, amount, max_costs, procurement_hash){
    logger.debug(`Add Request ${request_id} ${title} `)
    const contractCall = this.contract.methods['add_request'](request_id, title, amount, max_costs, procurement_hash)
    const receipt = await this.executeSend(contractCall, '0xCc30fD1B1Df91BD83AE80C9Afa256B793ac825d6', 0) //zero = msg.value used for placeBid and revealBid
    return receipt
  }

  //get request
  async getRequest(request_id) {
    return await this.contract.methods['get_request'](request_id).call()

  }

  //business: place bid
  async placeBid(request_id, sender_address, bidding_hash, offer_hash){
    logger.debug(`place Bid ${request_id} ${bidding_hash} ${offer_hash}`)
    const contractCall = this.contract.methods['place_bid'](request_id, bidding_hash, offer_hash)
    const receipt = await this.executeSend(contractCall, sender_address, 1000000000000000000) //1 ETH = depot for bidding in msg.value payload
    return receipt
  } 

  //business: reveal bid
  async revealBid(request_id, sender_address, price, nonce){
    logger.debug(`reveal Bid ${request_id} ${price} ${nonce}`)
    const contractCall = this.contract.methods['reveal_bid'](request_id, price, nonce)
    const receipt = await this.executeSend(contractCall, sender_address, 0) //zero = msg.value used for placeBid and revealBid
    
    return receipt
  } 

  //get bidding winner
  async getLowestBid(request_id){
    logger.debug(`getLowestBid`)
    return await this.contract.methods['get_lowest_bid'](request_id).call()
  } 

  //set request state
  async setState(request_id, state){
    logger.debug(`set State ${request_id} ${state}`)
    const contractCall = this.contract.methods['set_state'](request_id, state)
    const receipt = await this.executeSend(contractCall, '0xCc30fD1B1Df91BD83AE80C9Afa256B793ac825d6', 0) //zero = msg.value used for placeBid and revealBid
    return receipt
  } 

  //get request state
  async getState(request_id) {
    return await this.contract.methods['get_state'](request_id).call()
  }

  //get biddings from businesses
  async getProposals(request_id) {
    return await this.contract.methods['get_proposals'](request_id).call()
  }

  //business: withdraw depot and get payment
  async withdraw(request_id, sender_address){
    logger.debug(`withdraw ${request_id} ${sender_address}`)
    const contractCall = this.contract.methods['withdraw'](request_id)
    const receipt = await this.executeSend(contractCall, sender_address, 0) //zero = msg.value used for withdraw
    return receipt
  } 

  //business: create SSI
  async createIdentity(sender_address){
    logger.debug(`create Identity ${sender_address}`)
    const contractCall = this.contract.methods['create_identity'](sender_address)
    const receipt = await this.executeSend(contractCall, sender_address, 0) //zero = msg.value used for create identity
    return receipt
  }

  //set proof as an authority
  async setSignProof(authority, business_address){
    logger.debug(`set sign proof ${authority} ${business_address}`)
    const contractCall = this.contract.methods['set_sign_proof'](authority, business_address)
    if(authority == 'finance'){ 
      logger.debug(`set sign proof: authority finance will sign`)
      const receipt = await this.executeSend(contractCall, '0x695F46117a73B519921BC4475bF265eE747094E5', 0) //zero = msg.value used for create identity
      return receipt
    }
    if(authority == 'employee'){
      logger.debug(`set sign proof: authority employee will sign`)
      const receipt = await this.executeSend(contractCall, '0x52989aDfAfCE20f440E8e9247267F12CC23D37aA', 0) //zero = msg.value used for create identity
      return receipt
    }  
  }
  
  //get SSI proofs
  async getSignProof() {
    return await this.contract.methods['get_sign_proof']().call()
  }

  //government: reveal proof of winner
  async revealProof(request_id){
    logger.debug(`revealProof ${request_id}`)
    const contractCall = this.contract.methods['reveal_proof'](request_id)
    const receipt = await this.executeSend(contractCall, '0xCc30fD1B1Df91BD83AE80C9Afa256B793ac825d6', 0) //zero = msg.value used for create identity
    
    return receipt
  }

  //get proposal state
  async getProposalState(request_id, sender_address){
    logger.debug(`getProposalState ${request_id} ${sender_address} `)
    return await this.contract.methods['get_proposal_state'](request_id,sender_address).call()
  }

  //get reveal proof
  async getRevealProof(){
    logger.debug(`getRevealProof`)
    return await this.contract.methods['get_reveal_proof']().call()
  }

  //government: placing the order
  async setOrder(request_id){ //kann nur vom Staat ausgeführt werden 
    logger.debug(`setOrder ${request_id}`)
    const contractCall = this.contract.methods['set_order'](request_id)
    const receipt = await this.executeSend(contractCall, '0xCc30fD1B1Df91BD83AE80C9Afa256B793ac825d6', 0)
    return receipt
  } 

  //pay order depot government and business
  async setOrderDepot(request_id, sender_name){ //kann nur vom Staat ausgeführt werden 
    
    var winner_costs = await this.contract.methods['get_lowest_bid'](request_id).call()
    logger.debug(`winner_costs1 ${winner_costs}`)
    
    if("government" == sender_name){
    var winner_costs_government = winner_costs._lowest_bid * 1000000000000000000
    logger.debug(`winner_costs2 gov ${winner_costs_government}`)
    logger.debug(`setOrderDepot Gov ${request_id}`)
    const contractCall = this.contract.methods['set_order_depot'](request_id)
    const receipt = await this.executeSend(contractCall,'0xCc30fD1B1Df91BD83AE80C9Afa256B793ac825d6',winner_costs_government )
    return receipt
    }else{
    var winner_costs_business = winner_costs._lowest_bid * 0.05 * 1000000000000000000 //wei
    logger.debug(`winner_costs business ${winner_costs_business}`)
    logger.debug(`setOrderDepot Bus. ${request_id}`)
    logger.debug(`winner_costs._lowest_bidder ${winner_costs._lowest_bidder}`)
    const contractCall = this.contract.methods['set_order_depot'](request_id)
    const receipt = await this.executeSend(contractCall, winner_costs._lowest_bidder, winner_costs_business)
    return receipt
    } 
  
  } 

  //mark order as received
  async orderReceived(request_id, sender_address){ //kann nur vom Staat ausgeführt werden 
    logger.debug(`orderReceived ${request_id} ${sender_address}`)
    const contractCall = this.contract.methods['order_received'](request_id)
    const receipt = await this.executeSend(contractCall,sender_address , 0)
    return receipt
  }

  //inspect and validate order
  async signOrder(request_id, sender_address, quality, delivered_amount){ //kann nur vom Staat ausgeführt werden 
    logger.debug(`signOrder ${request_id} ${sender_address}`)
    const contractCall = this.contract.methods['sign_order'](request_id, quality, delivered_amount)
    const receipt = await this.executeSend(contractCall,sender_address, 0)
    return receipt
  } 

  //get delivery
  async getDelivery(request_id){ //kann nur vom Staat ausgeführt werden 
    logger.debug(`getDelivery ${request_id}`)
    const receipt = await await this.contract.methods['get_delivery'](request_id).call()
    return receipt
  } 

  //initialize modifiers for security matters
  async initModifier(init_authorities, init_gov_employee){ //kann nur vom Staat ausgeführt werden 
    logger.debug(`initModifier ${init_authorities} ${init_gov_employee}`)
    var receipt = 'null';
    for (var i = 0; i < init_authorities.length; i++){
      const contractCall = this.contract.methods['set_authorities'](init_authorities[i])
      receipt = await this.executeSend(contractCall,'0xCc30fD1B1Df91BD83AE80C9Afa256B793ac825d6', 0)
    } 
    for (var i = 0; i < init_gov_employee.length; i++){
      const contractCall = this.contract.methods['set_gov_employees'](init_gov_employee[i])
      receipt = await this.executeSend(contractCall,'0xCc30fD1B1Df91BD83AE80C9Afa256B793ac825d6', 0)
    } 
    return receipt
  } 
} 

module.exports = new Blockchain()