# PROCUREMENT

## Vorinstallation
Ubuntu 20.04
Ganache
Truffle
Node-RED
Node.js
Git

## Git Clone
Der Prototyp wurde auf dem HSLU Enterprise Lab entwickelt. Er ist unter diesem Link verfügbar: https://gitlab.enterpriselab.ch/gvoutat/procurement.git (nur für angemeldete HSLU User, falls es ganz public werden soll, bitte Mail an uns)
Wir empfehlen das Repository im Home Verzeichnis zu klonen
git clone https://gitlab.enterpriselab.ch/gvoutat/procurement.git

## Node-RED
Das Node-RED kann direkt mit dem Flow gestartet werden. 
Im CMD somit folgenden Befehl ausführen: 
node-red procurement/flows.json

Über den Browser kann nun auf die Flow Übersicht sowie Dashboard zugegriffen werden. 

## Ganache starten
Ganache starten und den folgenden Mnenomic einlesen. Account Index auf 20, gas price auf 0. Ausserdem
truffle-config.js file als Projekt hinzufügen.
table iron image pluck spare pledge artist finger goat aspect nature clinic

## Smart Contracts
Sobald Ganache up & running ist, können die Smart Contracts eingelesen werden. 
Dafür in das korrekte Unterverzeichnis wechseln und dann migrieren (deployen):
cd procurement/solidity
truffle migrate --network development

-----------------------------------

Anschliessend kann das Dashboard im Node-RED benutzt werden und Transaktionen werden in die Blockchain geschrieben. 

Nice to know:
- Logs werden im procurement/log Ordner erfasst
- Javascripts, welche die Zwischenstelle zu Node-RED und Solidity sind, befinden sich im procurement/js Ordner. 
Das main.js ist ein Methodensammler und übergibt diese jeweils an das blockchain.js Skript. 
Dieses Skript führt deine Transaktion auf der Blockchain aus oder macht eine Abfrage (Call()). 
