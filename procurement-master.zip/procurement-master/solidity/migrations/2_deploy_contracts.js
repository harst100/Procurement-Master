const procurement_contract = artifacts.require("procurement_contract");
const computation = artifacts.require("computation");

module.exports = function (deployer) {
  deployer.deploy(procurement_contract)
  deployer.deploy(computation)
}
